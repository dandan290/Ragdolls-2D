# Ragdolls-2D
2D ragdolls for godot. flails about, can be turned into a character pretty easily- I could provide basic movement code or tutorials if needed! 
***INSTALL INSTRUCTIONS***
Download the project, import it into yours! That's it!
